class EditorSession < ActiveRecord::Base 
  belongs_to :snippet
end